package Geometry;

//Imports

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Tester {

    public static void main(String[] args) {

        // Creating Arraylist

        ArrayList<Geom> geomArrayList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("Shapes.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();


            }

            // Exceptions

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Printing object information

        for (Geom geom : geomArrayList) {

            geom.printDescription();
        }

        System.out.println("-------------------------------------");

        // Finding if there is an object equal to the first one in the array list

        for (int i = 1; i < geomArrayList.size(); i++) {
            if (geomArrayList.get(0).equals(geomArrayList.get(i))) {
                System.out.println("Yes, there is an object equal to the first object in the list");
                break;
            }
        }

        // Finding smallest Geom object

        Geom smallest = geomArrayList.get(0);
        for (int i = 1; i < geomArrayList.size(); i++) {
            if (smallest.isLargerThan(geomArrayList.get(i)) > 0) {
                smallest = geomArrayList.get(i);
            }
        }
        System.out.println("-------------------------------------");
        System.out.println("Smallest: ");
        smallest.printDescription();
        System.out.println("-------------------------------------");

        // Finding largest Geom object

        Geom largest = geomArrayList.get(0);
        for (int i = 1; i < geomArrayList.size(); i++) {
            if (largest.isLargerThan(geomArrayList.get(i)) < 0) {
                largest = geomArrayList.get(i);
            }
        }
        System.out.println("-------------------------------------");
        System.out.println("Largest: ");
        largest.printDescription();
        System.out.println("-------------------------------------");


    }
}
