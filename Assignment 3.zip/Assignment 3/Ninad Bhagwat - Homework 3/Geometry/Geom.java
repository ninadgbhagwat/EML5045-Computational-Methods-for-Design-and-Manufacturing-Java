package Geometry;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Objects;

public abstract class Geom implements Relatable {
    // Common data
    protected String name = null;
    protected double[] origin = new double[3];

    // Abstract functions
    public abstract double computeArea();

    public abstract double computeVolume();

    public abstract void read(BufferedReader br) throws IOException;


    @Override
    public int isLargerThan(Relatable other) {
        Geom geom = (Geom) other;
        if (this.computeVolume() < geom.computeVolume())
            return -1;
        else if (this.computeVolume() > geom.computeVolume())
            return 1;
        else
            return 0;
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(name);
        result = 31 * result + Arrays.hashCode(origin);
        return result;
    }

    public void printDescription() {

        System.out.println("\nGeometry = " + name);
        System.out.println("Area = " + computeArea());
        System.out.println("Volume = " + computeVolume());
        System.out.println("To String = " + this.toString());
        System.out.println("Center located at: (" + origin[0] + ", " + origin[1] + ", " + origin[2] + ")");
    }

}
