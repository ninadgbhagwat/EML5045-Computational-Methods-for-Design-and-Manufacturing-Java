
package Geometry;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Objects;


public class Cylinder extends Geom3D {

    private double radius;
    private double height;

    public Cylinder() {

    }

    public Cylinder(double radius, double height) {
        this.radius = radius;
        this.height = height;
        name = "Cylinder";
    }

    @Override
    public double computeArea() {
        return 2.0 * Math.PI * radius * height + 2 * Math.PI * radius * radius;
    }

    @Override
    public double computeVolume() {
        return Math.PI * radius * radius * height;
    }

    @Override
    public String toString() {
        return "Cylinder {" + " " +
                "radius = " + radius +
                ", height=" + height + " " +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Cylinder)) return false;
        Cylinder cylinder = (Cylinder) o;
        return Double.compare(cylinder.radius, radius) == 0 && Double.compare(cylinder.height, height) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), radius, height);
    }

    @Override
    public void read(BufferedReader br) {
        try {
            String line = br.readLine();
            String[] words = line.split(" ");
            radius = Double.parseDouble(words[0]);
            height = Double.parseDouble(words[1]);
            origin[0] = Double.parseDouble(words[2]);
            origin[1] = Double.parseDouble(words[3]);
            origin[2] = Double.parseDouble(words[4]);
            name = "Cylinder";

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
