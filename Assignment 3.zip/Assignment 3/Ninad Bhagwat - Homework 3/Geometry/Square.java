
package Geometry;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Objects;

public class Square extends Geom2D {

    private double length;

    public Square() {

    }

    public Square(double length) {
        this.length = length;
        name = "Square";
    }

    @Override
    public double computeArea() {
        return length * length;
    }

    @Override
    public String toString() {
        return "Square {" + " " +
                "length = " + length + " " +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Square)) return false;
        Square square = (Square) o;
        return Double.compare(square.length, length) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), length);
    }

    @Override
    public void read(BufferedReader br) {
        try {
            String line = br.readLine();
            String[] words = line.split(" ");
            length = Double.parseDouble(words[0]);
            origin[0] = Double.parseDouble(words[1]);
            origin[1] = Double.parseDouble(words[2]);
            origin[2] = Double.parseDouble(words[3]);
            name = "Square";

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
