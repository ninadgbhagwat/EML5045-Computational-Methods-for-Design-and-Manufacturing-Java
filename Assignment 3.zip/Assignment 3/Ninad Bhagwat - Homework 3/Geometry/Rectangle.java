
package Geometry;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Objects;

public class Rectangle extends Geom2D {

    private double width;
    private double height;

    // Constructors

    public Rectangle() {

    }

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
        name = "Rectangle";
    }

    @Override
    public double computeArea() {
        return width * height;
    }

    @Override
    public String toString() {
        return "Rectangle {" + " " +
                "width = " + width +
                ", height = " + height + " " +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Rectangle)) return false;
        Rectangle rectangle = (Rectangle) o;
        return Double.compare(rectangle.width, width) == 0 && Double.compare(rectangle.height, height) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), width, height);
    }

    @Override
    public void read(BufferedReader br) {
        try {
            String line = br.readLine();
            String[] words = line.split(" ");
            width = Double.parseDouble(words[0]);
            height = Double.parseDouble(words[1]);
            origin[0] = Double.parseDouble(words[2]);
            origin[1] = Double.parseDouble(words[3]);
            origin[2] = Double.parseDouble(words[4]);
            name = "Rectangle";

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
