
package Geometry;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Objects;

public class Circle extends Geom2D {

    private double radius;

    public Circle() {

    }

    public Circle(double radius) {
        this.radius = radius;
        name = "Circle";
    }

    @Override
    public double computeArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public String toString() {
        return "Circle {" + " " +
                "radius = " + radius + " " +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Circle)) return false;
        Circle circle = (Circle) o;
        return Double.compare(circle.radius, radius) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), radius);
    }

    @Override
    public void read(BufferedReader br) {
        try {
            String line = br.readLine();
            String[] words = line.split(" ");
            radius = Double.parseDouble(words[0]);
            origin[0] = Double.parseDouble(words[1]);
            name = "Circle";
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}


