
package Geometry;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Objects;

public class Cube extends Geom3D {

    protected double length;

    // Constructors

    public Cube() {

    }

    public Cube(double length) {
        this.length = length;
        name = "Cube";
    }

    @Override
    public double computeArea() {
        return 6 * length * length;
    }

    @Override
    public double computeVolume() {
        return length * length * length;
    }

    @Override
    public String toString() {
        return "Cube {" + " " +
                "length = " + length + " " +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Cube)) return false;
        Cube cube = (Cube) o;
        return Double.compare(cube.length, length) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), length);
    }

    @Override
    public void read(BufferedReader br) {
        try {
            String line = br.readLine();
            String[] words = line.split(" ");
            length = Double.parseDouble(words[0]);
            origin[0] = Double.parseDouble(words[1]);
            origin[1] = Double.parseDouble(words[2]);
            origin[2] = Double.parseDouble(words[3]);
            name = "Cube";

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
