package Geometry;

public interface Relatable {

    int isLargerThan(Relatable other);
}