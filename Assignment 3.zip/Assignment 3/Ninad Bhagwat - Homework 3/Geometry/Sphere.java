
package Geometry;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Objects;

public class Sphere extends Geom3D {

    private double radius;

    public Sphere() {

    }

    public Sphere(double radius) {
        this.radius = radius;
        name = "Sphere";
    }

    @Override
    public double computeArea() {
        return 4 * Math.PI * radius * radius;
    }

    @Override
    public double computeVolume() {
        return Math.PI * (4.0 / 3.0) * radius * radius * radius;
    }

    @Override
    public String toString() {
        return "Sphere {" + " " +
                "radius = " + radius + " " +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Sphere)) return false;
        Sphere sphere = (Sphere) o;
        return Double.compare(sphere.radius, radius) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), radius);
    }

    @Override
    public void read(BufferedReader br) {
        try {
            String line = br.readLine();
            String[] words = line.split(" ");
            radius = Double.parseDouble(words[0]);
            origin[0] = Double.parseDouble(words[1]);
            origin[1] = Double.parseDouble(words[2]);
            origin[2] = Double.parseDouble(words[3]);
            name = "Sphere";

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
