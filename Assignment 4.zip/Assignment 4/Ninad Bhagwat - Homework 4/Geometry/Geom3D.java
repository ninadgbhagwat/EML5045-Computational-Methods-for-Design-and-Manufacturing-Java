
package Geometry;

public abstract class Geom3D extends Geom {

}
