
package Geometry;

public interface Relatable {

    public int isLargerThan(Relatable other);
}
