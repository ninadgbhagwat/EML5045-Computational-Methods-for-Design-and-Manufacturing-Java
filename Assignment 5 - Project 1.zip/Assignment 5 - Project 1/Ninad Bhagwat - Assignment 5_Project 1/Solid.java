import java.util.ArrayList;

class Solid {

    Lump lump;

    public Solid(Lump lump) {
        this.lump = lump;
    }


    String print() {
        return getClass() +
                lump.print() + " \n";
    }
}