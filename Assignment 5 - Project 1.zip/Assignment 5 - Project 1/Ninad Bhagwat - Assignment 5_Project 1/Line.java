public class Line extends Curve {

    Line(Point p1, Point p2) {
        super(p1, p2);
    }
}
