public class Plane extends Surface {
    public Plane(Loop l) {
        super(l);
    }
}
