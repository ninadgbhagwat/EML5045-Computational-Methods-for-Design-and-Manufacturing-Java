import java.util.ArrayList;

public class Face {

    ArrayList<Shell> shells;
    Loop l;

    public Face(Loop l) {

        this.l = l;
    }

    public void setShells(ArrayList<Shell> shells) {
        this.shells = shells;
    }


    String print() {

        return getClass() +
                "{ \n" +
                l.print() +
                '}';
    }
}

