import java.util.ArrayList;

public class Loop {

        ArrayList<Face> faces;
        ArrayList<CoEdge> coEdges;

        public Loop(ArrayList<CoEdge> coEdges) {
            this.coEdges = coEdges;
        }

    public void setFaces(ArrayList<Face> faces) {
        this.faces = faces;
    }

    @Override
        public String toString() {
            return "Loop{" +
                    ", coEdges=" + coEdges +
                    '}'+ "\n";
        }

        String print() {
            String f = "";
            for(CoEdge c : coEdges){
              f = f + c.print() + "\n";
            }
            return getClass() +
                    "{ \n" +
                   f +
                    '}';
        }
    }
