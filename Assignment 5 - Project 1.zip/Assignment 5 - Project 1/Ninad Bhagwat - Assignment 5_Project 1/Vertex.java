public class Vertex {

        Point p;


        Vertex(Point p) {
            this.p = p;
        }

        @Override
        public String toString() {
            return "Vertex{" +
                    "point =" + p +
                    '}'+ "\n";
        }

    String print() {
       return getClass() +
               "{" + p.print() +
               '}';
    }
    }

