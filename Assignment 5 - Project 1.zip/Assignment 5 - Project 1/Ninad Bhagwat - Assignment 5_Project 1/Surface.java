public class Surface extends Face {
    public Surface(Loop l) {
        super(l);
    }
}
