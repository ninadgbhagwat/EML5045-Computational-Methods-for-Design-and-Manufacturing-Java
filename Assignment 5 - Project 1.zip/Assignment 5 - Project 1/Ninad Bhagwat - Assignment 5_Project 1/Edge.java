import java.util.ArrayList;

public class Edge {
    Vertex v1;
    Vertex v2;
    ArrayList<CoEdge> coEdges;


    public Edge(Vertex v1, Vertex v2) {
        this.v1 = v1;
        this.v2 = v2;
    }

    public void printLine() {
        double x_val = v2.p.x - v1.p.x;
        double y_val = v2.p.y - v1.p.y;
        double z_val = v2.p.z - v1.p.z;

        String a = "Line{" +
                "x = " + v1.p.x + "+" + "(" + x_val + ")" + "t , " +
                "y = " + v1.p.y + "+" + "(" + y_val + ")" + "t , " +
                "z = " + v1.p.z + "+" + "(" + z_val + ")" + "t" +
                '}';
        System.out.println(a);

    }

    public void setCoEdges(ArrayList<CoEdge> coEdges) {
        this.coEdges = coEdges;
    }

    String print() {
        return getClass() +
                "{" + v1.print() +
                " , " + v2.print() +
                '}';

    }
}

