import java.util.ArrayList;

public class Tester {

    static void printPlane(Vertex v1, Vertex v2, Vertex v3) {
        String a = "";
        double val_x = v1.p.x - v2.p.x;
        double temp_x = v1.p.x - v3.p.x;
        double val_y = v1.p.y - v2.p.y;
        double temp_y = v1.p.y - v3.p.y;
        double val_z = v1.p.z - v2.p.z;
        double temp_z = v1.p.z - v3.p.z;

        a = "Plane{" +
                "x = " + v1.p.x + "+ s" + "(" + val_x + ")" + " t(" + temp_x + ")" +
                "y = " + v1.p.y + "+ s" + "(" + val_y + ")" + " t(" + temp_y + ")" +
                "z = " + v1.p.z + "+ s" + "(" + val_z + ")" + " t(" + temp_z + ")" +
                '}';
        System.out.println(a);
    }


    public static void main(String[] args) {

        // Creating points

        Point P1 = new Point(0.0, 0.0, 0.0);
        Point P2 = new Point(1.0, 0.0, 0.0);
        Point P3 = new Point(1.0, 1.0, 0.0);
        Point P4 = new Point(0.0, 1.0, 0.0);
        Point P5 = new Point(0.0, 0.0, 1.0);
        Point P6 = new Point(1.0, 0.0, 1.0);
        Point P7 = new Point(1.0, 1.0, 1.0);
        Point P8 = new Point(0.0, 1.0, 1.0);

        // Creating Vertices

        Vertex V1 = new Vertex(P1);
        Vertex V2 = new Vertex(P2);
        Vertex V3 = new Vertex(P3);
        Vertex V4 = new Vertex(P4);
        Vertex V5 = new Vertex(P5);
        Vertex V6 = new Vertex(P6);
        Vertex V7 = new Vertex(P7);
        Vertex V8 = new Vertex(P8);

        // Creating Curves

        Line C1 = new Line(P1, P2);
        Line C2 = new Line(P2, P3);
        Line C3 = new Line(P3, P4);
        Line C4 = new Line(P4, P1);
        Line C5 = new Line(P1, P5);
        Line C6 = new Line(P2, P6);
        Line C7 = new Line(P3, P7);
        Line C8 = new Line(P4, P8);
        Line C9 = new Line(P5, P6);
        Line C10 = new Line(P6, P7);
        Line C11 = new Line(P7, P8);
        Line C12 = new Line(P8, P5);

        // Creating Edges

        Edge E1 = new Edge(V1, V2);
        Edge E2 = new Edge(V2, V3);
        Edge E3 = new Edge(V3, V4);
        Edge E4 = new Edge(V4, V1);
        Edge E5 = new Edge(V1, V5);
        Edge E6 = new Edge(V2, V6);
        Edge E7 = new Edge(V3, V7);
        Edge E8 = new Edge(V4, V8);
        Edge E9 = new Edge(V5, V6);
        Edge E10 = new Edge(V6, V7);
        Edge E11 = new Edge(V7, V8);
        Edge E12 = new Edge(V8, V5);

        // Creating Co-Edges

        CoEdge CE1 = new CoEdge(E1, 1);
        CoEdge CE2 = new CoEdge(E2, 1);
        CoEdge CE3 = new CoEdge(E3, 1);
        CoEdge CE4 = new CoEdge(E4, 1);
        CoEdge CE5 = new CoEdge(E1, -1);
        CoEdge CE6 = new CoEdge(E5, 1);
        CoEdge CE7 = new CoEdge(E9, 1);
        CoEdge CE8 = new CoEdge(E6, -1);
        CoEdge CE9 = new CoEdge(E6, 1);
        CoEdge CE10 = new CoEdge(E10, 1);
        CoEdge CE11 = new CoEdge(E7, -1);
        CoEdge CE12 = new CoEdge(E2, -1);
        CoEdge CE13 = new CoEdge(E9, -1);
        CoEdge CE14 = new CoEdge(E12, 1);
        CoEdge CE15 = new CoEdge(E11, -1);
        CoEdge CE16 = new CoEdge(E10, -1);
        CoEdge CE17 = new CoEdge(E11, 1);
        CoEdge CE18 = new CoEdge(E9, 1);
        CoEdge CE19 = new CoEdge(E8, -1);
        CoEdge CE20 = new CoEdge(E3, -1);
        CoEdge CE21 = new CoEdge(E5, -1);
        CoEdge CE22 = new CoEdge(E4, -1);
        CoEdge CE23 = new CoEdge(E8, 1);
        CoEdge CE24 = new CoEdge(E12, -1);

        // Creating Loops

        ArrayList<Loop> loopArrayList = new ArrayList<>();

        ArrayList<CoEdge> coEdges1 = new ArrayList<>();
        coEdges1.add(CE1);
        coEdges1.add(CE2);
        coEdges1.add(CE3);
        coEdges1.add(CE4);

        Loop L1 = new Loop(coEdges1);
        loopArrayList.add(L1);

        ArrayList<CoEdge> coEdges2 = new ArrayList<>();
        coEdges2.add(CE5);
        coEdges2.add(CE6);
        coEdges2.add(CE7);
        coEdges2.add(CE8);

        Loop L2 = new Loop(coEdges2);
        loopArrayList.add(L2);

        ArrayList<CoEdge> coEdges3 = new ArrayList<>();
        coEdges3.add(CE9);
        coEdges3.add(CE10);
        coEdges3.add(CE11);
        coEdges3.add(CE12);

        Loop L3 = new Loop(coEdges3);
        loopArrayList.add(L3);

        ArrayList<CoEdge> coEdges4 = new ArrayList<>();
        coEdges4.add(CE13);
        coEdges4.add(CE14);
        coEdges4.add(CE15);
        coEdges4.add(CE16);

        Loop L4 = new Loop(coEdges4);
        loopArrayList.add(L4);

        ArrayList<CoEdge> coEdges5 = new ArrayList<>();
        coEdges5.add(CE17);
        coEdges5.add(CE18);
        coEdges5.add(CE19);
        coEdges5.add(CE20);

        Loop L5 = new Loop(coEdges5);
        loopArrayList.add(L5);

        ArrayList<CoEdge> coEdges6 = new ArrayList<>();
        coEdges6.add(CE21);
        coEdges6.add(CE22);
        coEdges6.add(CE23);
        coEdges6.add(CE24);

        Loop L6 = new Loop(coEdges6);
        loopArrayList.add(L6);

// Creating Faces

        Face F1 = new Face(L1);
        Face F2 = new Face(L2);
        Face F3 = new Face(L3);
        Face F4 = new Face(L4);
        Face F5 = new Face(L5);
        Face F6 = new Face(L6);


        ArrayList<Face> face1 = new ArrayList<>();
        face1.add(F1);
        face1.add(F2);
        face1.add(F3);
        face1.add(F4);
        face1.add(F5);
        face1.add(F6);

        // Creating Shell

        Shell S1 = new Shell(face1);

        // Creating Lump

        Lump Lu1 = new Lump(S1);

        // Creating Solid
        Solid cube = new Solid(Lu1);

        System.out.println(cube.print());


        //Line-Edge Equations
        System.out.println("Equations");

        System.out.println("L1");
        E1.printLine();
        System.out.println("L2");
        E2.printLine();
        System.out.println("L3");
        E3.printLine();
        System.out.println("L4");
        E4.printLine();
        System.out.println("L5");
        E5.printLine();
        System.out.println("L6");
        E6.printLine();
        System.out.println("L7");
        E7.printLine();
        System.out.println("L8");
        E8.printLine();
        System.out.println("L9");
        E9.printLine();
        System.out.println("L10");
        E10.printLine();
        System.out.println("L11");
        E11.printLine();
        System.out.println("L12");
        E12.printLine();

//Creating Plane Equations

        System.out.println("Plane Equations \n");
        System.out.println("plane1");
        printPlane(V1, V2, V3);
        System.out.println("plane2");
        printPlane(V1, V5, V6);
        System.out.println("plane3");
        printPlane(V2, V3, V7);
        System.out.println("plane4");
        printPlane(V5, V6, V7);
        System.out.println("plane5");
        printPlane(V3, V4, V8);
        System.out.println("plane6");
        printPlane(V1, V4, V5);


    }

}



