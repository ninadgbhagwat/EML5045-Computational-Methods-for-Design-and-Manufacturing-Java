import java.util.ArrayList;

public class CoEdge {

    ArrayList<Loop> loops;
    Edge edge;
    int direction;

    public CoEdge(Edge edge, int direction) {
        this.edge = edge;
        this.direction = direction;
    }

    public void setLoops(ArrayList<Loop> loops) {
        this.loops = loops;
    }

    String print() {
        return getClass() +
                "{" +
                edge.print() +
                ", direction=" + direction +
                "}" + "\n";
    }
}

