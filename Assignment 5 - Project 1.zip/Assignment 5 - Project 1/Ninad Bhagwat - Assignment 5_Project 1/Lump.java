import java.util.ArrayList;

public class Lump {

    ArrayList<Solid> solids;
    Shell shell;

    public Lump(Shell shell) {

        this.shell = shell;
    }

    public void setSolids(ArrayList<Solid> solids) {
        this.solids = solids;
    }


    String print() {
        return getClass() +
                shell.print() + " \n";
    }
}

