import java.util.ArrayList;

public class Shell {

    ArrayList<Lump> lumps;
    ArrayList<Face> faces;

    public Shell(ArrayList<Face> faces) {
        this.faces = faces;
    }

    public void setLumps(ArrayList<Lump> lumps) {
        this.lumps = lumps;
    }


    String print() {
        String r = "";

        for (Face f : faces) {
            r = r + f.print() + " \n";
        }
        return getClass() +
                "{ \n" +
                r +
                '}';


    }
}
