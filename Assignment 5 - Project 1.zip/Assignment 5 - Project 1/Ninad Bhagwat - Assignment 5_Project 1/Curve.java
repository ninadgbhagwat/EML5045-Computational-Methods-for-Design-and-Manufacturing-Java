public class Curve {

    Point p1;
    Point p2;

    Curve(Point p1, Point p2) {
        this.p1 = p1;
        this.p2 = p2;
    }

    @Override
    public String toString() {
        return "Curve{" +
                "p1=" + p1 +
                ", p2=" + p2 +
                '}' + "\n";
    }

    void print() {
        System.out.println("class name = " + getClass());
        System.out.println("p1  = " + p1.toString() +
                "p2  = " + p2.toString() + "\n");

    }
}

