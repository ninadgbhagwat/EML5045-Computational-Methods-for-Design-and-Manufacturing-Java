/*
 * PlotCanvas.java
 */

import Jama.Matrix;

import java.awt.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import javax.vecmath.*;
import java.text.DecimalFormat;
import javax.swing.JFrame;

//==============================================================================
// PlotCanvas class definition
//==============================================================================
public class PlotCanvas extends Canvas {

    private double[][] yValues = null;
    private double[] xValues = null;
    //private final String name;
    public String xLabel = "x";
    public String yLabel = "y";
    public String title = "Title";
    public double minY = 0;
    public double maxY = 0;
    public boolean writeData = false;
    public static boolean dots = false;
    public static int dotSize = 7;

    //==========================================================================
    public PlotCanvas(double[] xVal, double[][] yVal, String title, String xlbl, String ylbl) {
        super();
        this.title = title;
        xLabel = xlbl;
        yLabel = ylbl;
        setDataPoints(xVal, yVal);
    }

    //==========================================================================
    public final void setDataPoints(double[] xVals, double[][] yVals) {
        xValues = xVals;
        yValues = yVals;
        setBackground(Color.white);
    } // setDataPoints

    public void setLimits(double upper, double lower) {
        minY = lower;
        maxY = upper;
    }

    //==========================================================================
    // existing function in Canvas : draw 2D graphics
    @Override
    public void paint(Graphics g) {
        plotCurves();
    } // end of if(stPList.size() > 1)

    //==========================================================================
    public void plotCurves() {
        Graphics2D g = (Graphics2D) getGraphics();
        g.setStroke(new BasicStroke(2));
        drawCoordinateAxes();
        double den = xValues[xValues.length - 1] - xValues[0];
        if (yValues != null) {
            for (double[] yValue : yValues) {
                Color color = getColor();
                for (int j = 0; j < yValue.length - 1; j++) {
                    double xValue1, xValue2 = 0.0;
                    if (xValues.length == yValue.length) {
                        xValue1 = (xValues[j] - xValues[0]) / den;
                        xValue2 = (xValues[j + 1] - xValues[0]) / den;
                    } else {
                        xValue1 = ((double) j) / ((double) (yValue.length - 1));
                        xValue2 = ((double) j + 1) / ((double) (yValue.length - 1));
                    }
                    Point3d firstPt = new Point3d(xValue1, yValue[j], 0.0);
                    Point3d secondPt = new Point3d(xValue2, yValue[j + 1], 0.0);
                    Point pt1 = convertCoordToPixel(firstPt);
                    Point pt2 = convertCoordToPixel(secondPt);
                    g.setColor(color); // set the color for curve
                    g.drawLine(pt1.x, pt1.y, pt2.x, pt2.y);
                    g.setColor(new Color(0.0f, 0.0f, 0.0f));    // set the color for data points
                    if (dots) {
                        int ds2 = dotSize / 2;
                        g.fillOval(pt1.x - ds2, pt1.y - ds2, dotSize, dotSize);
                        if (j == yValue.length - 2) {
                            g.fillOval(pt2.x - ds2, pt2.y - ds2, dotSize, dotSize);
                        }
                    }
                }
            }
        }
    } // end plotCurve

    int rr = 10, gg = 125, bb = 255;

    private Color getColor() {
        Color col = new Color(rr, gg, bb);
        rr += 55;
        gg += 105;
        bb += 25;
        if (bb > 255) bb = 10;
        if (gg > 255) gg = 10;
        if (rr > 255) rr = 10;
        return col;
    }

    //==========================================================================
    // function to draw coordinate axes
    private void drawCoordinateAxes() {
        if (minY == maxY) {
            checkResetMaxMin(yValues);
        }

        Graphics2D g2d = (Graphics2D) getGraphics();
        g2d.setStroke(new BasicStroke(2));
        Dimension dim = new Dimension();
        getSize(dim);

        double tmpHeight = dim.getHeight();
        double tmpWidth = dim.getWidth();
        double xCoord1 = 0.1 * tmpWidth;
        double xCoord2 = 0.95 * tmpWidth;
        double yCoord1 = 0.9 * tmpHeight;
        double yCoord2 = 0.1 * tmpHeight;
        double yCoord0 = yCoord1; // value for location of x-axis
        if (minY * maxY < 0) {
            yCoord0 = yCoord1 - minY * (yCoord2 - yCoord1) / (maxY - minY);
        } else if (maxY <= 0) {
            yCoord0 = yCoord2;
        }

        g2d.setColor(Color.black);
        Font txtFont = new Font("Ariel", Font.BOLD, 24);
        g2d.setFont(txtFont);

        // Title
        if (title != null) {
            g2d.drawString(title, (int) (0.4 * tmpWidth), (int) (0.05 * tmpHeight));
        }

        // Draw axes
        g2d.setColor(Color.black); // set the color for axes
        g2d.drawLine((int) xCoord1, (int) yCoord0, (int) xCoord2, (int) yCoord0);
        g2d.drawLine(
                (int) xCoord1, (int) yCoord1 + (int) (0.05 * tmpHeight),
                (int) xCoord1, (int) yCoord2 - (int) (0.05 * tmpHeight));

        // Draw arrow heads
        int delta = (int) (tmpHeight + tmpWidth) / 100;
        Polygon tri = new Polygon();
        tri.npoints = 3;
        tri.xpoints = new int[]{(int) xCoord2, (int) (xCoord2 + delta), (int) xCoord2};
        tri.ypoints = new int[]{(int) yCoord0 - delta / 3, (int) yCoord0, (int) yCoord0 + delta / 3};
        g2d.fillPolygon(tri);
        tri.xpoints = new int[]{(int) xCoord1 + delta / 3, (int) xCoord1, (int) xCoord1 - delta / 3};
        int yy = (int) yCoord2 - (int) (0.05 * tmpHeight);
        tri.ypoints = new int[]{yy, yy - delta, yy};
        g2d.fillPolygon(tri);
        tri.xpoints = new int[]{(int) xCoord1 + delta / 3, (int) xCoord1, (int) xCoord1 - delta / 3};
        yy = (int) yCoord1 + (int) (0.05 * tmpHeight);
        tri.ypoints = new int[]{yy, yy + delta, yy};
        g2d.fillPolygon(tri);

        int numPts = 10;
        for (int i = 0; i <= numPts; i++) {
            double ratio = ((double) i) / ((double) (numPts));
            double xCoord = xCoord1 + ratio * 0.8 * tmpWidth;
            double yCoord = yCoord1 - ratio * 0.8 * tmpHeight;
            Point xPt = new Point((int) xCoord, (int) yCoord0);
            Point yPt = new Point((int) xCoord1, (int) yCoord);
            g2d.setColor(Color.black);    // set the color for data points
            g2d.fillOval(xPt.x - 2, xPt.y - 2, 5, 5);
            g2d.fillOval(yPt.x - 2, yPt.y - 2, 5, 5);

            double yValue = minY + ratio * (maxY - minY);
            g2d.drawString(format(yValue), yPt.x - (int) (3.5 * delta), yPt.y + delta / 3);
            double xTrans = tmpWidth / (4 * (numPts - 1));
            double yTrans = (tmpHeight / (3 * numPts));
            if (xValues != null) {
                double xValue1 = xValues[0] + ratio * (xValues[xValues.length - 1] - xValues[0]);
                if (i != 0) {
                    g2d.drawString(format(xValue1), xPt.x - (int) xTrans, xPt.y + (int) yTrans);
                }
            }
        } // end of i

        // Labels
        int xi = (int) xCoord1 + delta / 2;
        int yi = (int) yCoord2 - (int) 2.5 * delta;
        g2d.drawString(yLabel, xi, yi);
        xi = (int) xCoord2 - 2 * delta;
        yi = (int) yCoord0 - delta / 2;
        g2d.drawString(xLabel, xi, yi);

    } // drawCoordinateAxes()

    //==========================================================================
    private String format(double value) {
        DecimalFormat df = new DecimalFormat();
        if (Math.abs(value) < 1.0e-2 || Math.abs(value) > 1.0e3) {
            df.applyPattern("0.##E0");
        } else {
            df.applyPattern("0.##");
        }
        return df.format(value);
    }

    //==========================================================================
    // code to check whether the difference between max and min values are significant
    // enough to justify use of different colors and to reset lower or upper limits
    // to zero when appropriate
    public void checkResetMaxMin(double[][] data) {
        minY = data[0][0];
        maxY = data[0][0];
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                if (data[i][j] > maxY) {
                    maxY = data[i][j];
                } else if (data[i][j] < minY) {
                    minY = data[i][j];
                }
            }
        }
        double tempMax;
        if (Math.abs(maxY) >= Math.abs(minY)) {
            tempMax = maxY;
        } else {
            tempMax = minY;
        }
        double checkRatio = ((maxY - minY) / Math.abs(tempMax));
        if (Math.abs(tempMax) < 1.0e-14) {
            maxY = minY = 0.0;
        } else if (checkRatio < 0.1) {
            if (maxY > 0) {
                minY = maxY - 0.1 * Math.abs(maxY);
            } else {
                maxY = minY + 0.1 * Math.abs(minY);
            }
        } else { // also set limit to zero if close enough
            if ((Math.abs(maxY / minY) > 1.0e4) || Math.abs(minY) < 1.0e-14) {
                minY = 0.0;
            } else if (Math.abs(minY / maxY) > 1.0e4 || Math.abs(maxY) < 1.0e-14) {
                maxY = 0.0;
            }
        }
    } // checkResetMaxMin

    //==========================================================================
    // convert pixel point to point in the coordinate
    private Point convertCoordToPixel(Point3d pt3d) {
        // find the size of the canvas, say (lx,ly)-- lower point, (ux,uy)-- upper point
        // then plot in the region which lies in ( Lower corner -- (lx + 0.1*L, ly+0.1*H), Upper Corner (lx + 0.9*L, ly+0.9*H))
        // project the data points in this region.

        double minX = 0.;
        double maxX = 1.0;

        double xRatio = (pt3d.x - minX) / (maxX - minX);
        double yRatio = (pt3d.y - minY) / (maxY - minY);

        Dimension dim = new Dimension();
        getSize(dim);

        double tmpHeight = dim.getHeight();
        double tmpWidth = dim.getWidth();

        double xPixCoord = 0.1 * tmpWidth + xRatio * 0.8 * tmpWidth;
        double yPixCoord = 0.9 * tmpHeight - yRatio * 0.8 * tmpHeight;
        Point pt = new Point((int) xPixCoord, (int) yPixCoord);
        return pt;
    } // end of convertCoordToPixel(Point3d pt, int[] pixelPos)

    //==========================================================================
    public static void main(String[] args) {

        // Creating Array Lists to store the extracted X and Y coordinates
        ArrayList<Double> xlist = new ArrayList<>();
        ArrayList<Double> ylist = new ArrayList<>();


        //Buffered reader to read the files and extract the X and Y coordinates
        try (BufferedReader reader = new BufferedReader(new FileReader("src/Test3.txt"))) {
            String line;

            while ((line = reader.readLine()) != null) {
                line = line.trim();
                String[] coordinates = line.split("[\\s,]+");
                xlist.add(Double.parseDouble(coordinates[0]));
                ylist.add(Double.parseDouble(coordinates[1]));
            }

            // Creating n*n matrix for using the cardinal spline matrix equation
            int n = xlist.size();
            double[][] matrix = new double[n][n];


            for (int i = 0; i < n; i++) {
                matrix[0][i] = 0.0;
            }
            matrix[0][0] = 2.0;
            matrix[0][1] = 1.0;

            for (int i = 0; i < n; i++) {
                matrix[n - 1][i] = 0.0;
            }
            matrix[n - 1][n - 2] = 1.0;
            matrix[n - 1][n - 1] = 2.0;


            for (int i = 1; i < n - 1; i++) {
                for (int j = 0; j < n; j++) {
                    matrix[i][j] = 0.0;
                }
            }

            for (int i = 1; i < n - 1; i++) {
                int k = i - 1;
                matrix[i][k] = 1.0;
                matrix[i][k + 1] = 4.0;
                matrix[i][k + 2] = 1.0;
            }

            for (int i = 0; i < matrix.length; i++) {
                for (int j = 0; j < matrix[i].length; j++) {
                    System.out.print(matrix[i][j] + " ");
                }
                System.out.println();
            }

            //x coordinates column vector in the cardinal spline vector equation
            double[][] rhsX = new double[n][1];
            for (int i = 1; i < n - 1; i++) {
                rhsX[i][0] = xlist.get(i + 1) - xlist.get(i - 1);
            }
            rhsX[0][0] = xlist.get(1) - xlist.get(0);
            rhsX[n - 1][0] = xlist.get(n - 1) - xlist.get(n - 2);

            //y coordinates column vector in the cardinal spline vector equation
            double[][] rhsY = new double[n][1];
            for (int i = 1; i < n - 1; i++) {
                rhsY[i][0] = ylist.get(i + 1) - ylist.get(i - 1);
            }
            rhsY[0][0] = ylist.get(1) - ylist.get(0);
            rhsY[n - 1][0] = ylist.get(n - 1) - ylist.get(n - 2);

            // Solving for first derivative column vector for x coordinates in cardinal spline matrix equation
            Matrix x = new Matrix(matrix).solve(new Matrix(rhsX));
            double[][] fx = x.getArray();

            for (int i = 0; i < fx.length; i++) {
                for (int j = 0; j < fx[i].length; j++) {
                    System.out.print(fx[i][j] + " ");
                }
                System.out.println();
            }

            // Solving for first derivative column vector for y coordinates in cardinal spline matrix equation
            Matrix y = new Matrix(matrix).solve(new Matrix(rhsY));
            double[][] fy = y.getArray();


            for (int i = 0; i < fy.length; i++) {
                for (int j = 0; j < fy[i].length; j++) {
                    System.out.print(fy[i][j] + " ");
                }
                System.out.println();
            }

            // creating values of parameter u in 0 to 1 range
            double delU = 0.2;
            double U = 1;
            ArrayList uXlist = new ArrayList();

            for (double u = 0; u < U; u += delU) {
                uXlist.add(u);
            }

            // creating array list for x and y points to be plotted
            ArrayList<Double> xRlist = new ArrayList<>();
            ArrayList<Double> yRlist = new ArrayList<>();

            int count = 0;

            for (int i = 0; i < xlist.size() - 1; i++) {

                for (double u = 0; u < U; u += delU) {

                    // Hermite Polynomials
                    double H0 = 1 - (3 * Math.pow(u, 2)) + (2 * Math.pow(u, 3));
                    double H1 = (3 * Math.pow(u, 2)) - (2 * Math.pow(u, 3));
                    double H2 = u - (2 * Math.pow(u, 2)) + (Math.pow(u, 3));
                    double H3 = (Math.pow(u, 3)) - (Math.pow(u, 2));

                    // Calculating the curve equation
                    double xR1 = xlist.get(i) * H0 + xlist.get(i + 1) * H1 + fx[i][0] * H2 + fy[i + 1][0] * H3;
                    xRlist.add(xR1);

                    double yR1 = ylist.get(i) * H0 + ylist.get(i + 1) * H1 + fy[i][0] * H2 + fy[i + 1][0] * H3;
                    yRlist.add(yR1);

                }
            }

            //Plotting the curves
            double[] xffinal = xRlist.stream().mapToDouble(Double::doubleValue).toArray();
            double[] yffinal = yRlist.stream().mapToDouble(Double::doubleValue).toArray();
            plot(xffinal, yffinal,
                    1, xRlist.size(), "Curve",
                    "X", "Y");

            //The provided plot methods are working well with input files with small number of points like "Test.txt"
            // and "Test2.txt". For file "Batman_Curve.txt" the plot method is having some issues. But, getting the
            // interpolated coordinates and plotting them into MATLAB shows that the plot method in MATLAB is working
            // well for all the files and shows that the cardinal spline interpolation is working as expected.

            // Exceptions

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    } // plot

    //==========================================================================
    public static void plot(String title,
                            double[] xVal, double[][] yVal,
                            String xLabel, String yLabel) {
        JFrame frame = new JFrame();
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                System.exit(0);
            }
        });
        frame.setTitle(title);
        frame.setSize(1024, 800);
        Canvas plt = new PlotCanvas(xVal, yVal, title, xLabel, yLabel);
        frame.add(plt);
        frame.setVisible(true);
    } // plot

    public static void plot(String title,
                            double[] xVal, double[] yVal,
                            String xLabel, String yLabel) {
        double[][] yVals = new double[1][];
        yVals[0] = yVal;
        plot(title, xVal, yVals, xLabel, yLabel);
    }

    //==========================================================================
    public static void plot(double[] xVal, double[][] yVal,
                            int start, int end, String title,
                            String xLabel, String yLabel) {
        JFrame frame = new JFrame();
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                System.exit(0);
            }
        });
        frame.setSize(1024, 800);
        double[] xVal1 = Arrays.copyOfRange(xVal, start, end);
        double[][] yVal1 = new double[yVal.length][];
        for (int ii = 0; ii < yVal.length; ii++) {
            yVal1[ii] = Arrays.copyOfRange(yVal[ii], start, end);
        }
        Canvas plt = new PlotCanvas(xVal1, yVal1, title, xLabel, yLabel);
        frame.setTitle(title);
        frame.add(plt);
        frame.setVisible(true);
    } // plot

    public static void plot(double[] xVal, double[] yVal,
                            int start, int end, String title,
                            String xLabel, String yLabel) {
        double[][] yVals = new double[1][];
        yVals[0] = yVal;
        plot(xVal, yVals, start, end, title, xLabel, yLabel);

    }


} // end PlotCanvas class definition

