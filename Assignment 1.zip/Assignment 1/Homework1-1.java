/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package homework1;

// Bhagwat, Ninad Gurudas

//Imports
import java.util.Arrays;
import java.util.Scanner;


public class Homework1 {
    
    // Problem 1 - Dot Product of two vectors
    // Two collinear vectors are considered as arrays
    public static double dotProduct(double[] a, double[] b){
        double sum = 0;
        int n = a.length;
        for (int i = 0; i < n; i++){
        sum = sum + a[i] * b[i];
        }
        return sum;
    }
    
    // Problem 2 - Matrix multiplication 
    public static void matMultiply(double[][] aMat, double[][] bMat, double[][] cMat){
       System.out.println("\n2) Matrix Multiplications is : ");
        for (int i = 0; i < aMat.length; i++){
            for (int j = 0; j < bMat[0].length; j++){
                cMat[i][j] = 0;
                for (int k = 0; k < bMat.length; k++){
                    cMat[i][j]+= aMat[i][k]* bMat[k][j];
                }
                System.out.print(cMat[i][j]+" ");
            }
           System.out.println();
        }
         
    }

    // Problem 3 - Breaking a string
    public static String getLineWords(String line){
         
        System.out.println("input string - " + line); 
        return Arrays.toString( line.split( "[\\s,]+" ));
    }
    
    public static void main(String[] args) {
        
        // Dot product
        
        double[] a = {2,4,8};
        double[] b = {7,5,4};
        double ans = dotProduct(a,b);
        System.out.println("1) Dot Product of the two vectors is : " + ans);
        
        // Matrix Multiplication
        
        double[][] aMat = {{2,2,2},{2,2,2},{2,2,2}};
        double[][] bMat = {{2,2,2},{2,2,2},{2,2,2}};
        double[][] cMat = new double[aMat.length][bMat[0].length];
        matMultiply(aMat, bMat, cMat);
       
        
        // Breaking a string
        
        Scanner sc = new Scanner(System.in);
        System.out.println("\nEnter a line:");
        String line = sc.nextLine();
        System.out.println("3) output is - " + getLineWords(line));

    }
    
}
