package Geometry;

public class Tester {

    public static void main(String[] args) {
        Geom[] array = new Geom[8];

        array[0] = new Square(5);
        array[1] = new Circle(10);
        array[2] = new Rectangle(10, 5);
        array[3] = new Ellipse(6, 4);
        array[4] = new Cube(5);
        array[5] = new Sphere(10);
        array[6] = new Cuboid(10, 5, 5);
        array[7] = new Cone(5, 10);

        for (Geom geom : array) {
            System.out.println("Object Class Name = " + geom.showInformation());
            System.out.println("Area = " + geom.computeArea());
            System.out.println("Volume = " + geom.computeVolume());
            System.out.println("\n");
        }
    }
}