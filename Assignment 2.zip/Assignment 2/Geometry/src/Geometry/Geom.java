package Geometry;

public abstract class Geom {

    public abstract String showInformation();

    public abstract double computeArea();

    public abstract double computeVolume();
}

abstract class Geom2D extends Geom {
    public double thickness = 1;
}

class Square extends Geom2D {
    private double side;

    public Square(double side) {

        this.side = side;
    }

    public String showInformation() {
        return "Class Name: " + Square.class.getName() +
                "\nSuper Class: " + Square.class.getSuperclass() +
                "\nSuper Super Class: " + Square.class.getSuperclass().getSuperclass();
    }

    public double computeArea() {
        return Math.pow(side, 2);
    }

    public double computeVolume() {
        return Math.pow(side, 2) * thickness;
    }

}

class Circle extends Geom2D {
    private double radius;

    public Circle(double radius) {

        this.radius = radius;
    }

    public String showInformation() {

        return "Class Name: " + Circle.class.getName() +
                        "\nSuper Class: " + Circle.class.getSuperclass() +
                        "\nSuper Super Class: " + Circle.class.getSuperclass().getSuperclass() ;


    }

    public double computeArea() {
        return Math.PI * Math.pow(radius, 2);
    }

    public double computeVolume() {
        return Math.PI * Math.pow(radius, 2) * thickness;
    }
}

class Rectangle extends Geom2D {
    private double length;
    private double width;

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    public String showInformation() {
        return "Class Name: " + Rectangle.class.getName() +
                "\nSuper Class: " + Rectangle.class.getSuperclass() +
                "\nSuper Super Class: " + Rectangle.class.getSuperclass().getSuperclass() ;
    }

    public double computeArea() {
        return length * width;
    }

    public double computeVolume() {
        return length * width * thickness;
    }


}

class Ellipse extends Geom2D {
    private double majorRadius;
    private double minorRadius;

    public Ellipse(double majorRadius, double minorRadius) {
        this.majorRadius = majorRadius;
        this.minorRadius = minorRadius;

    }

    public String showInformation() {

        return "Class Name: " + Ellipse.class.getName() +
                "\nSuper Class: " + Ellipse.class.getSuperclass() +
                "\nSuper Super Class: " + Ellipse.class.getSuperclass().getSuperclass() ;
    }

    public double computeArea() {
        return Math.PI * majorRadius * minorRadius;
    }

    public double computeVolume() {
        return Math.PI * majorRadius * minorRadius * thickness;
    }
}


abstract class Geom3D extends Geom {
    public abstract double computeVolume();
}

class Cube extends Geom3D {
    private double side;

    public Cube(double side) {
        this.side = side;
    }

    public String showInformation() {
        return "Class Name: " + Cube.class.getName() +
                "\nSuper Class: " + Cube.class.getSuperclass() +
                "\nSuper Super Class: " + Cube.class.getSuperclass().getSuperclass() ;
    }

    public double computeArea() {
        return 6 * Math.pow(side, 2);
    }

    public double computeVolume() {
        return Math.pow(side, 3);
    }

}

class Sphere extends Geom3D {
    private double radius;

    public Sphere(double radius) {
        this.radius = radius;
    }

    public String showInformation() {
        return "Class Name: " + Sphere.class.getName() +
                "\nSuper Class: " + Sphere.class.getSuperclass() +
                "\nSuper Super Class: " + Sphere.class.getSuperclass().getSuperclass() ;
    }

    public double computeArea() {
        return 4 * Math.PI * Math.pow(radius, 2);
    }

    public double computeVolume() {
        return (4 / 3) * Math.PI * Math.pow(radius, 3);
    }

}


class Cuboid extends Geom3D {
    private double length, width, height;

    public Cuboid(double length, double width, double height) {
        this.length = length;
        this.width = width;
        this.height = height;
    }

    public String showInformation() {
        return "Class Name: " + Cuboid.class.getName() +
                "\nSuper Class: " + Cuboid.class.getSuperclass() +
                "\nSuper Super Class: " + Cuboid.class.getSuperclass().getSuperclass() ;
    }

    public double computeArea() {
        return 2 * ((length * width) + (length * height) + (width * height));
    }

    public double computeVolume() {
        return length * width * height;

    }


}

class Cone extends Geom3D {
    private double radius, height;

    public Cone(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }

    public String showInformation() {
        return "Class Name: " + Cone.class.getName() +
                "\nSuper Class: " + Cone.class.getSuperclass() +
                "\nSuper Super Class: " + Cone.class.getSuperclass().getSuperclass() ;
    }

    public double computeArea() {
        return Math.PI * radius * (radius + Math.sqrt((Math.pow(radius, 2) + Math.pow(height, 2))));
    }

    public double computeVolume() {
        return 0.33 * Math.PI * Math.pow(radius, 2) * height;
    }


}
